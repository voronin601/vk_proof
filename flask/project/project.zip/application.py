from flask import Flask, render_template, redirect, request, session, url_for
import json
import datetime
import time
app = Flask(__name__)
app.secret_key = 'its my life'
app.permanent_session_lifetime = datetime.timedelta(hours=1)

@app.route("/", methods = ['GET', 'POST'])
def hello():
    if request.method == 'GET':
        return render_template('./start.html')
    elif request.method == 'POST':
        if (request.form.get('log') == '1' and request.form.get('pas') == '1') or 'user' in session:
            session['user'] = True
            return redirect(url_for('table'))

@app.route("/table", methods = ['GET', 'POST'])
def table():
    if request.method == 'GET':
        if 'user' in session and session['user'] == True:
            with open('./static/json/user-key.json', 'r') as spis:
                data = json.load(spis)
            return render_template('./tab_key.html', spis = spis)
        else:
            return "Error data"
    elif request.method == 'POST':
        if 'key_add' in request.form:
            us = request.form.get('user')
            key = request.form.get('key')
            with open('./static/json/user-key.json', 'r') as spis:
                data = json.load(spis)
            if us in data:
                return "У этого пользователя уже есть ключ"
            data[us] = key
            with open('./static/json/user-key.json', 'w') as spis:
                json.dump(data, spis)
            return redirect(url_for('table'))
        elif 'key_del' in request.form:
            us = request.form.get('user')
            with open('./static/json/user-key.json', 'r') as spis:
                data = json.load(spis)
            if us in data:
                data.pop(us)
            else: return "Нет такого USER ID"
            with open('./static/json/user-key.json', 'w') as spis:
                json.dump(data, spis)
            return redirect(url_for('table'))

@app.route('/table/<idd>', methods = ['GET'])  
def proof(idd = None):
    with open('./static/json/user-key.json', 'r') as spis:
        if idd in json.load(spis):
            return 'True'
        else: 
            return 'False'

if __name__ == "__main__":
    app.run(host = '0.0.0.0', debug = True)